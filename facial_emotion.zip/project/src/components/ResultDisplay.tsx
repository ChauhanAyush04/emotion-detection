import React from 'react';
import { Brain, Image as ImageIcon, AlertCircle } from 'lucide-react';

interface ResultDisplayProps {
  resultImageUrl?: string;
  emotionTexts?: string[];
  isLoading: boolean;
  error?: string;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ 
  resultImageUrl, 
  emotionTexts, 
  isLoading, 
  error 
}) => {
  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
            <Brain className="w-8 h-8 text-blue-600 animate-pulse" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            Analyzing Emotions
          </h3>
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
          <p className="text-gray-600 mt-4">
            Please wait while we process your image...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 rounded-xl shadow-lg p-8 border border-red-200">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
            <AlertCircle className="w-8 h-8 text-red-600" />
          </div>
          <h3 className="text-xl font-semibold text-red-800 mb-2">
            Analysis Failed
          </h3>
          <p className="text-red-600">
            {error}
          </p>
        </div>
      </div>
    );
  }

  if (!resultImageUrl && (!emotionTexts || emotionTexts.length === 0)) {
    return null;
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
          <Brain className="w-8 h-8 text-green-600" />
        </div>
        <h3 className="text-2xl font-semibold text-gray-800">
          Emotion Analysis Results
        </h3>
      </div>

      <div className="space-y-6">
        {resultImageUrl && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-lg font-medium text-gray-700">
              <ImageIcon size={20} />
              Analyzed Image
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <img 
                src={resultImageUrl} 
                alt="Analysis Result" 
                className="w-full max-w-md mx-auto rounded-lg shadow-sm"
              />
            </div>
          </div>
        )}

        {emotionTexts && emotionTexts.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-lg font-medium text-gray-700">
              <Brain size={20} />
              Detected Emotions
            </div>
            <div className="grid gap-3">
              {emotionTexts.map((emotion, index) => (
                <div 
                  key={index}
                  className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4 border border-blue-100"
                >
                  <p className="text-gray-800 font-medium">
                    {emotion}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};