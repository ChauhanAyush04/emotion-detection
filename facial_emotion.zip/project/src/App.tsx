import React, { useState, useCallback } from 'react';
import { Brain, Upload, Camera } from 'lucide-react';
import { FileUpload } from './components/FileUpload';
import { WebcamCapture } from './components/WebcamCapture';
import { ResultDisplay } from './components/ResultDisplay';

type InputMode = 'file' | 'webcam';

interface AnalysisResult {
  result_image_url?: string;
  emotion_texts?: string[];
  error?: string;
}

function App() {
  const [inputMode, setInputMode] = useState<InputMode>('file');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [webcamImage, setWebcamImage] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleFileSelect = useCallback((file: File | null) => {
    setSelectedFile(file);
    setResult(null);
  }, []);

  const handleWebcamCapture = useCallback((imageData: string) => {
    setWebcamImage(imageData);
    setResult(null);
  }, []);

  const dataURItoBlob = (dataURI: string): Blob => {
    const byteString = atob(dataURI.split(',')[1]);
    const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: mimeString });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (inputMode === 'file' && !selectedFile) {
      alert('Please select an image file.');
      return;
    }
    
    if (inputMode === 'webcam' && !webcamImage) {
      alert('Please capture an image using the webcam.');
      return;
    }

    setIsLoading(true);
    setResult(null);

    try {
      const formData = new FormData();
      
      if (inputMode === 'file' && selectedFile) {
        formData.append('image', selectedFile);
      } else if (inputMode === 'webcam' && webcamImage) {
        const blob = dataURItoBlob(webcamImage);
        formData.append('image', blob, 'webcam-capture.jpg');
      }

      const response = await fetch('/predict', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error('Error:', error);
      setResult({
        error: error instanceof Error ? error.message : 'An unexpected error occurred'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const isSubmitDisabled = isLoading || 
    (inputMode === 'file' && !selectedFile) || 
    (inputMode === 'webcam' && !webcamImage);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full mb-6 shadow-lg">
            <Brain className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Facial Emotion Recognition System
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Upload an image or use your webcam to analyze facial expressions and detect emotions using advanced AI technology.
          </p>
        </div>

        {/* Input Mode Selection */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8 border border-gray-200">
          <div className="flex justify-center mb-8">
            <div className="inline-flex bg-gray-100 rounded-lg p-1">
              <button
                type="button"
                onClick={() => setInputMode('file')}
                className={`flex items-center gap-2 px-6 py-3 rounded-md font-medium transition-all ${
                  inputMode === 'file'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                <Upload size={20} />
                Upload Image
              </button>
              <button
                type="button"
                onClick={() => setInputMode('webcam')}
                className={`flex items-center gap-2 px-6 py-3 rounded-md font-medium transition-all ${
                  inputMode === 'webcam'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                <Camera size={20} />
                Use Webcam
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {inputMode === 'file' ? (
              <FileUpload 
                onFileSelect={handleFileSelect}
                selectedFile={selectedFile}
                isDisabled={isLoading}
              />
            ) : (
              <WebcamCapture 
                onCapture={handleWebcamCapture}
                isDisabled={isLoading}
              />
            )}

            <div className="text-center">
              <button
                type="submit"
                disabled={isSubmitDisabled}
                className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold text-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                <Brain size={24} />
                {isLoading ? 'Analyzing...' : 'Analyze Emotions'}
              </button>
            </div>
          </form>
        </div>

        {/* Results */}
        {(result || isLoading) && (
          <ResultDisplay
            resultImageUrl={result?.result_image_url}
            emotionTexts={result?.emotion_texts}
            isLoading={isLoading}
            error={result?.error}
          />
        )}
      </div>
    </div>
  );
}

export default App;